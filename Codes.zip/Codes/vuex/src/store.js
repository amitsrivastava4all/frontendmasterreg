import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)  // $store

export default new Vuex.Store({
  state: {
    order:{},
    cart:{},
    product:{products:[]},
    calc:{first:0,second:0,result:0}
  },
  mutations: {
    ADD(state, payload){
      let result = parseInt(payload.first) + parseInt(payload.second);
      let calc= {first: payload.first, second:payload.second,result:result};
     // console.log('Result is ',result);
      this.state.calc = calc;
    }
  },
  actions: {

  }
})
