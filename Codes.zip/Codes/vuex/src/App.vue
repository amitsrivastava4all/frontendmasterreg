<template>
<div>
   <input v-model="first" type="text">
   <br>
  <input v-model="second" type="text">
  <br>
  <button @click="adder()">Add</button>
  Result is {{$store.state.calc.result}}
</div>
 
</template>

<script>


export default {
  name: 'app',
  data(){
    return {
    first:0,
    second:0
    };
  },
  methods:{
    adder(){
      this.$store.commit('ADD',{'first':this.first, 'second':this.second});
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
