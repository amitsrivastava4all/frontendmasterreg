<template>
    <div>
        <h2>I am First Vue {{xyz}}</h2>
       
    </div>
</template>

<script>
    export default {
        props:{xyz:''}
       

    }
</script>

<style lang="scss" scoped>

</style>