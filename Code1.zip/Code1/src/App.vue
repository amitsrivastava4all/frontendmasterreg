<template>
  <div>
    <First :xyz="mydata"/>
    <HelloWorld/>
    <h1>I am App Component</h1>
    <button @click="show()">Ok</button>
    Count is {{counter}}
  </div>
</template>

<script>

import HelloWorld from './components/HelloWorld.vue';
import First from './components/First.vue';
  export default {
    components:{ HelloWorld, First},
    data(){
      return {
        counter:0,
        mydata:'Hello I am Parent'
      }
    },
    methods: {
      show(){
        this.counter++;
      }
    },
  }
</script>

<style lang="scss" scoped>

</style>